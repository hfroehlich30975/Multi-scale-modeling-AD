# SNP pathway score
# snp2pathway: two column data.frame (refsnp_id, pathway)
# polyphen_sift: Polyphen and SIFT predictions (data.frame - refsnp_id, polyphen_prediction, sift_prediction)

snp.mat <- read.table("snp4pathways.txt", colClasses = factor())
names(snp.mat)<- as.character(unlist(snp.mat[1,]))
snp.mat <- snp.mat[-1,]
# names(snp.mat)[1:10] 
# [1] "FID"          "IID"          "PAT"          "MAT"         
# [5] "SEX"          "PHENOTYPE"    "rs3094315_C"  "rs12562034_A"
# [9] "rs3934834_T"  "rs6687776_T"

# so we remove first 6 columns and make rownames as PTID("FID")
row.names(snp.mat)<- snp.mat[,1]
snp.mat <- snp.mat[,-c(1:6)]

# snp.mat: SNP matrix (result of retrieve.snp.matrix - colmns = SNPs, rows = patients)

col_names<- names(snp.mat)

library(biomaRt)
mysnp=useEnsembl(biomart="snp", dataset="hsapiens_snp")

polyphen_sift_results = getBM(attributes=c("refsnp_id", "polyphen_prediction",
                                           "sift_prediction"), mart=mysnp,
                              filters = "snp_filter", value=col_names)

polyphen_sift_results$polyphen_prediction <- gsub("^$",NA,polyphen_sift_results$polyphen_prediction)
polyphen_sift_results$sift_prediction <- gsub("^$",NA, polyphen_sift_results$sift_prediction)

i <- which(is.na(polyphen_sift_results$sift_prediction))

polyphen_sift <- polyphen_sift_results

pathway.score = function(snp.mat, snp2pathway, polyphen_sift){
  snps.damage = polyphen_sift$refsnp_id[polyphen_sift$polyphen_prediction %in% c("damaging", "possibly damaging", "probably damaging") | polyphen_sift$sift_prediction %in% c("deleterious", "deleterious - low confidence")] # potentially damaging SNPs
  pathways = unique(snp2pathway$Pathway)
  scores = c()
  for(p in pathways){
    # names(snp2pathway)
    # [1] "rsID"     "Pathways"
    mysnps = intersect(as.character(snp2pathway$rsID[snp2pathway$Pathway == p]), colnames(snp.mat)) # pathway SNPs in data
    mysnps2 = intersect(mysnps, snps.damage) # pathway SNPs in data that are potentially damaging
    if(length(mysnps2) > 0)
      sc = apply(snp.mat, 1, function(x) sum(x[mysnps2] > 0) / length(mysnps)) # pathway scores for each patient
    else
      sc = rep(0, NROW(snp.mat))
    scores = cbind(scores, sc) 
  }
  colnames(scores) <- pathways
  rownames(scores) <- rownames(snp.mat)
  scores
}

pathway_burden <- pathway.score(snp.mat, snp2pathway, polyphen_sift)
