source("https://bioconductor.org/biocLite.R")
biocLite("KEGGREST")
library(KEGGREST)
kegg_human_pathways <- keggList("pathway", "hsa")

pathway_ids <- names(kegg_human_pathways)
pathway_ids <- gsub("path:", "",pathway_ids)

kegg_pathway_genes <- sapply(pathway_ids, function(x) keggGet(x)[[1]]["GENE"])
kegg_pathway_genes <- sapply(kegg_pathway_genes, function(x) gsub("\\;.*","",x))
kegg_pathway_genes <- sapply(kegg_pathway_genes, function(x) x[nzchar(gsub("[0-9]+", "", x))])

kegg_human_pathways <- sapply(kegg_human_pathways, function(x) gsub("\\-.*","",x))



# indx <- sapply(kegg_pathway_genes, length)
indx <- lengths(kegg_pathway_genes)
pathway_genes <- as.data.frame(do.call(rbind,lapply(kegg_pathway_genes, `length<-`,
                                          max(indx))))

rownames(pathway_genes) <- kegg_human_pathways

################################################################

# MalathiSIDona/pathDESeq gitHub package has all the Reactome pathways.


install.packages("devtools")
library(devtools)

install.packages("curl")
library(curl)

install_github("MalathiSIDona/pathDESeq", force = T)
library(pathDESeq)

# load reactome pathways with respective genes
data("Reactome24.Hs")
rownames(Reactome24.Hs) <- Reactome24.Hs[,1]
Reactome24.Hs <- Reactome24.Hs[,-1]


# install.packages("gtools")
library(gtools)

pathways <- smartbind(pathway_genes, Reactome24.Hs)
rownames(pathways)[1:318]<- rownames(pathway_genes)
rownames(pathways)[319:342] <- rownames(Reactome24.Hs)
