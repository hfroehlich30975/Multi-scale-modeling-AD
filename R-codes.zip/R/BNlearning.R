library(bnlearn)
library(arules)
library(missForest)
library(parallel)
library(doMC)
registerDoMC(cores=10)

load("gbm_final.rda")
load("dat4model.rda")
colnames(model_final$pca$eigenvect) = paste("EV", 1:NCOL(model_final$pca$eigenvect), sep="")
dat.full = cbind.data.frame(adni.0, pathway_burden, adni_geneotyping[rownames(adni.0),snp_knowledge_adni], model_final$pca$eigenvect)
dat.full$AD_Flag = factor(dat.full$AD_Flag)
snps = c(colnames(dat.full)[grep("rs[0-9]+", colnames(dat.full))], "APOE4.0") # SNPs / genetic markers
for(s in snps)
    dat.full[,s] = factor(dat.full[,s])
isnum = sapply(1:NCOL(dat.full), function(i) !is.factor(dat.full[,i]))
dat.full[,isnum] = as.matrix(dat.full[,isnum])
data(iris) # weird - you first need to load the iris data to make missForest work
dat.imp = missForest(dat.full, ntree=1000, parallelize = "forests")
save(dat.full, dat.imp, file="dat_full.rda")

dat.disc = bnlearn::discretize(data.frame(dat.imp$ximp[,union(rownames(model_final$features), c("Event_Time", "AD_Flag", "APOE4.0")),drop=FALSE]), method="interval")
#dat.disc = cbind.data.frame(data.frame(apply(dat.imp$ximp, 2, bnlearn::discretize, method="interval")), dat.full[,sapply(1:NCOL(dat.full), function(x) !is.numeric(dat.full[,x]))])
pathways = intersect(colnames(pathway_burden), colnames(dat.disc))
population = c(colnames(dat.disc)[grep("EV", colnames(dat.disc))],"subpopulation", "PTETHCAT", "PTRACCAT", "PTGENDER") # eigenvectors (subpopulations)
population = intersect(population, colnames(dat.disc))
clin = setdiff(intersect(colnames(adni.0), colnames(dat.disc)), c("APOE4.0", "subpopulation"))
imaging = colnames(dat.disc)[grep("Region_", colnames(dat.disc))] # neuroimaging features
ntests = c("CDRSB.0", "ADAS11.0", "ADAS13.0", "MMSE.0", colnames(dat.disc)[grep("RAVLT", colnames(dat.disc))], colnames(dat.disc)[grep("Ecog", colnames(dat.disc))]) # neuropsychological test results
ntests = intersect(ntests, colnames(dat.disc))

# blacklist
bl = data.frame()
# no clinical variables as input to SNPs, pathways and subpopulations
for(snp in c(snps, pathways, population)){
  bl = rbind.data.frame(bl, data.frame(from=clin, to=rep(snp, each=length(clin)))) 
}
# no neuropsychological test result as input to imaging feature
for(im in imaging){
  bl = rbind.data.frame(bl, data.frame(from=ntests, to=rep(im, each=length(ntests)))) 
}
bl = rbind.data.frame(bl, data.frame(from=colnames(dat.disc), to="AGE.0")) # no input to "AGE.0"
bl = rbind.data.frame(bl, data.frame(from=setdiff(clin, c("AGE.0", "PTEDUCAT")), to="DX.0")) # no clinical input to "DX.0", except for age and education
bl = rbind.data.frame(bl, data.frame(from=clin, to="PTEDUCAT")) # no clinical input to education
bl = rbind.data.frame(bl, data.frame(from="AD_Flag", to=colnames(dat.disc))) # no output from clinical endpoint
bl = rbind.data.frame(bl, data.frame(from="Event_Time", to=colnames(dat.disc))) # no output from clinical endpoint

# whitelist
wl = data.frame(from="AD_Flag", to="Event_Time") # enforce edge from event to event time

cl=makeCluster(10)
cvres1 = bn.cv(dat.disc, "rsmax2", runs=10, fit="bayes", loss="logl",  algorithm.args = list(maxp=5, blacklist=bl, whitelist=wl, restart=10), cluster=cl) 
cvres2 = bn.cv(dat.disc, "mmhc", runs=10, fit="bayes", loss="logl",  algorithm.args = list(maxp=5, blacklist=bl,  whitelist=wl, restart=10), cluster=cl) 
cvres3 = bn.cv(dat.disc, "hc", runs=10, fit="bayes", loss="logl", algorithm.args = list(maxp=5, blacklist=bl,  whitelist=wl, restart=10, score="bic"), cluster=cl) 
cvres4 = bn.cv(dat.disc, "tabu", runs=10, fit="bayes", loss="logl", algorithm.args = list(maxp=5, blacklist=bl,  whitelist=wl, restart=10, score="bic"), cluster=cl)
cvres5 = bn.cv(dat.disc, "si.hiton.pc", runs=10, fit="bayes", loss="logl", algorithm.args = list(blacklist=bl,  whitelist=wl, undirected=FALSE), cluster=cl)
cvres6 = bn.cv(dat.disc, "mmpc", runs=10, fit="bayes", loss="logl", algorithm.args = list(blacklist=bl, whitelist=wl, undirected=FALSE), cluster=cl)
pdf(file="BN_CV.pdf")
plot(cvres1, cvres2, cvres3, cvres4, cvres5, cvres6, xlab=c("rsmax2", "mmhc", "hc", "tabu", "si.hiton.pc", "mmpc")) # iamb and fast-iamb might be too slow
dev.off()

boot.stren = boot.strength(dat.disc, algorithm="tabu", R=1000, algorithm.args = list(maxp=5, blacklist=bl, whitelist=wl, restart=50, score="bic"), cluster=cl)
finalBN = tabu(dat.disc, maxp=5, blacklist=bl,  whitelist=wl, restart=50, score="bic")
stopCluster(cl)

thresh = 0.5
bn.av = averaged.network(boot.stren, threshold = thresh)
G = as.graphNEL(bn.av)

boot.stren2 = boot.stren[boot.stren$strength > thresh & boot.stren$direction >= 0.5, ]
write.csv(boot.stren2, file="BNBootstrapped.csv")

#
boot.stren2 = merge(boot.stren2, model_final$features, by.x = "from", by.y="var", all.x = TRUE)
boot.stren2 = merge(boot.stren2, model_final$features, by.x = "to", by.y="var", all.x = TRUE)
dfreq = data.frame(freq)
boot.stren2 = merge(boot.stren2, dfreq, by.x = "from", by.y="Var1", all.x = TRUE)
boot.stren2 = merge(boot.stren2, dfreq, by.x = "to", by.y="Var1", all.x = TRUE)
boot.stren2 = boot.stren2[,-3]
boot.stren2 = boot.stren2[,c(2,1,3:NCOL(boot.stren2))]
write.csv(boot.stren2, file="BNBootstrapped.csv")

nodes = data.frame(node=union(boot.stren2$to, boot.stren2$from))
nodes = merge(nodes, model_final$features, by.x="node", by.y="var", all.x=TRUE)
nodes = merge(nodes, dfreq, by.x="node", by.y="Var1", all.x=TRUE)
write.csv(nodes, file="Nodes.csv", row.names = FALSE)
