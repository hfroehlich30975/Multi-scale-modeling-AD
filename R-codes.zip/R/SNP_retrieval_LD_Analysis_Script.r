# Snps from DisGeNet, SCAIView and GWAS-Catalog are downloaded
# from the server with Query
# "Alzheimer's Disease and Organism "Homo sapiens"

Disgenet_data <- read.csv("disgenet_snps.csv", header = TRUE) 
# Get SNP IDs
disgenet_snps <- as.vector(Disgenet_data$snpid)
# Remove Duplicate Entries
i <- which(duplicated(disgenet_snps))
disgenet_snps <- disgenet_snps[-i]


#########################################################################
gwas_catalog_data <- read.csv("gwas_catalog_snps.csv", header = T)

# Get SNP IDs
gwas_catalog_snps <- as.vector(gwas_catalog_data$SNPS)

# Formating to same Scale
rs_ids <- grep("^rs", gwas_catalog_snps)
rs_ids <- gwas_catalog_snps[rs_ids]
i <- grep("; ", rs_ids)

# some SNPs were like
# rs12345; rs23456; rs456789
# therefore split into separate rows
need_spliting <- rs_ids[i]
rs_ids <- rs_ids[-i]
splitted <- unlist(strsplit(need_spliting, split = "; "))

rs_ids <- c(rs_ids, splitted)

# SNPs which do not have RSID but chromosome location or NAs
differnt_snps <- gwas_catalog_snps[-grep("^rs", gwas_catalog_snps)] #removed

gwas_catalog_snps <- rs_ids

# Remove Duplicate Entries
i <- which(duplicated(gwas_catalog_snps))
gwas_catalog_snps <- gwas_catalog_snps[-i]

rm(need_spliting,rs_ids,splitted)

#########################################################################

scaiView_Data <- read.csv("test.csv", header = T, sep = ";")
# Get SNP IDs
scaiView_SNPs <- as.vector(scaiView_Data$Internal.Identifier)

# bringing in standard format
scaiView_SNPs <- gsub("^RS","rs", scaiView_SNPs, ignore.case = T)

# Remove Duplicate Entries
i <- which(duplicated(scaiView_SNPs)) #empty

rm(i)
#########################################################################

# Merging SNPs from all the Knowledge Retrieved Databases
snp_list <- union(disgenet_snps, gwas_catalog_snps)
snp_list <- union(snp_list, scaiView_SNPs)


########################################################################

# Perform HaploReg Analysis
# LD Pruning (r^2 < = 0.2)

# Package "haploR" is required to perform LD Block Analysis 
# programatically.
library(haploR) 
Sys.time()
res <- sapply(snp_list, function(x) {
  # queryHaploreg() is used to query HaploReg to get all SNPs 
  # that are in LD to a given SNP from HaploReg Server.
  # http://archive.broadinstitute.org/mammals/haploreg/haploreg.php
  haplo_res <- as.data.frame(queryHaploreg(query = x, timeout = 100))
  
  # r^2 less than 0.2 is for LD Pruning
  haplo_res <- haplo_res[which(haplo_res$r2<0.2 | haplo_res$r2 == 0.2),]
  haplo_res <- haplo_res$rsID
  return(haplo_res)
})
Sys.time()
ld_pruning_results <- unlist(res)
ld_pruning_results <- union(snp_list, ld_pruning_results) # weak correlated features
write(ld_pruning_results, file = "ld_pruning.txt")

#####################################################################

# To get the first feature matrix the list was then searched in 
# ADNI genotyping profiles to get the SNP scores for each patient
# Done in python by Mohammad Asif Emon

#####################################################################

