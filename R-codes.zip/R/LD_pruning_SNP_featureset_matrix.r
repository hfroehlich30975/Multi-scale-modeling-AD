LD_pruning_SNP_matrix <- read.table("SNPs_weak_ld20.txt", colClasses = factor())
names(LD_pruning_SNP_matrix)<- as.character(unlist(LD_pruning_SNP_matrix[1,]))
LD_pruning_SNP_matrix <- LD_pruning_SNP_matrix[-1,]
# names(LD_pruning_SNP_matrix)[1:10] 
# [1] "FID"         "IID"         "PAT"         "MAT"         "SEX"        
# [6] "PHENOTYPE"   "rs1801131_C" "rs1801133_T" "rs678849_C"  "rs2271933_T"

# so we remove first 6 columns and make rownames as PTID("FID")
row.names(LD_pruning_SNP_matrix)<- LD_pruning_SNP_matrix[,1]
LD_pruning_SNP_matrix <- LD_pruning_SNP_matrix[,-c(1:6)]


# LD_pruning_SNP_matrix: SNP matrix (result of retrieve.LD_pruning_SNP_matrixrix - colmns = SNPs, rows = patients)

col_names<- names(LD_pruning_SNP_matrix)
col_names <- gsub("\\_[A,C,T,G]$","", col_names)
names(LD_pruning_SNP_matrix) <- col_names
