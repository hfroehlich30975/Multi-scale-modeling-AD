eqtl_snp_genes <- eqtl_hgnc_rsID[,c(7,3)]
trans_eqtls <- trans_eqtls[,c(1,6)]
names(trans_eqtls) <- c("rsID", "hgnc_symbol")
eqtl_snp_genes <- as.data.frame(rbind(eqtl_snp_genes,trans_eqtls))
names(gene_snp_map)<- c("rsID", "hgnc_symbol")
all_snps_eqtl_knowledge <- as.data.frame(rbind(eqtl_snp_genes,
                                               gene_snp_map))
all_snps_eqtl_knowledge <- unique(all_snps_eqtl_knowledge)

snp_list <- all_snps_eqtl_knowledge$rsID
write(snp_list, file = "snp_list_pathways.txt")

names(pathway_gene_dataframe)<- c("Pathways","hgnc_symbol")

SNP_gene_pathway <- merge(all_snps_eqtl_knowledge, pathway_gene_dataframe, by="hgnc_symbol",  all.x=T)

SNP_gene_pathway <- SNP_gene_pathway[which(!is.na(SNP_gene_pathway$Pathways)),]

snp2pathway <- SNP_gene_pathway[,c(2,3)]

######################################################################

